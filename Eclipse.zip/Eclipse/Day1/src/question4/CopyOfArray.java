package question4;

public class CopyOfArray {
	public static int[] copyOf(int[] array){
		int n=array.length;
     	int[] copy=new int[n];
     	for(int i=0;i<n;i++){
     		copy[i]=array[i];
     	}
     	return copy;
		
	}
public static void main(String[] args)//main method
{
	int[] array={1,2,3,4};//initializing 1st array
	System.out.print("Array Before Copying: ");
	for(int i=0;i<array.length;i++)//printing array before copying
	{
		System.out.print(" "+array[i]);
	}
	System.out.println("");//printing next line
	int[] cp=new int[array.length];//intializing new array 
	cp=copyOf(array);//passing 1st array in 2nd array
	System.out.print("Array After Copying: ");
	for(int i=0;i<cp.length;i++)//printing 2nd array
	{
		System.out.print(" "+cp[i]);
	}
		

	}

}
