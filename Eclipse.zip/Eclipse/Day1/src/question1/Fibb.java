package question1;
//Java Program to display the first 20 Fibonacci numbers And Display their Average
public class Fibb
{
	   public static void main(String[] args) {
		   double sum =0;
	       System.out.println("The first 20 Fibonacci numbers are: ");
	       for (int i = 1; i <= 20; i++) {
	           System.out.print(fibonacci(i) + " ");
	           sum += fibonacci(i);
	       }
	       double average=sum/20;
	       System.out.println();
	       System.out.println("The average is "+average);
	   }

	   public static int fibonacci(int n) {
	       if (n == 0) {
	           return 0;
	       } else if (n == 1) {
	           return 1;
	       } else {
	           return fibonacci(n - 1) + fibonacci(n - 2);
	       }
	   }
}
