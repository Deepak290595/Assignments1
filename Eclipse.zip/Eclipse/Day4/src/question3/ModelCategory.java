package question3;


public abstract class ModelCategory
{
	abstract void category(String s);
}
