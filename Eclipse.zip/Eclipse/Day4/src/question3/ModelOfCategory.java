package question3;


public class ModelOfCategory extends ModelCategory{
	
	void category(String k) {
		if (k.equalsIgnoreCase("SUV"))
			System.out.println("TATA SUFARI");
		else if (k.equalsIgnoreCase("SEDAN"))
			System.out.println("TATA INDIGO");
		else if (k.equalsIgnoreCase("ECONOMY"))
			System.out.println("TATA INDICA");
		else if (k.equalsIgnoreCase("MINI"))
			System.out.println("TATA NANO");
		else
			System.out.println("WRONG INPUT");
	}

}
