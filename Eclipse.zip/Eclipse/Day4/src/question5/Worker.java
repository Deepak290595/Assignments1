package question5;
import java.util.Scanner;
class HourlyWorker extends Worker{
	void computePay(int h){
		if(h<=40){
			int x = this.salaryrate*h;
			System.out.println("Salary for "+h+ " is "+x);
		}
		else
		{
			int x = (this.salaryrate*(h-40)/2)+this.salaryrate*40;
			System.out.println("Salary for "+h+ " hours is "+x);
		}
	}
}
class SalariedWorker extends Worker{
	void computePay(int h){
		int x = this.salaryrate*h;
		System.out.println("Salary for "+h+ " is "+x);
	}
}
public class Worker {
	private String name;
	int salaryrate =100;
	void computePay(int h){
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the choice : ");
		System.out.println("1 for Hourly Worker"+ "\n"+"2 for Salaried Worker");
		int n = sc.nextInt();
		switch(n){
		case 1:
			Worker w = new HourlyWorker();
			System.out.println("Enter no. of hours: ");
			int h=sc.nextInt();
			w.computePay(h);
			break;
		case 2:
			w = new SalariedWorker();
			System.out.println("Enter no. of hours: ");
			int h1=sc.nextInt();
			w.computePay(h1);
			break;
		}
	}

}
