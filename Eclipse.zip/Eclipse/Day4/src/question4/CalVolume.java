package question4;
import java.util.Scanner;
public class CalVolume {
		double volume (double a)                	 	// volume of cube
	    {
	           return (a*a*a);
	    }

	    double volume(double r, double h)      	// volume of cylinder
	    {
	           return (3.14519F*r*r*h) ;
	    }

	    double volume(double l, double b, double h1)      // volume of rectangular
	    {
	           return (l*b*h1);
	    }
	public static void main(String[] args) {
		CalVolume v = new CalVolume();
		Scanner sc = new Scanner(System.in);
		System.out.println("1 for cube"+"\n"+"2 for Cylinder"+"\n"+"3 for Rectangle");
		int n = sc.nextInt();
		switch(n){
		case 1:
			System.out.println("Enter side :");
			double a = sc.nextInt();
			System.out.println("Volume of a cube = "+v.volume(a));
			break;
		case 2:
			System.out.println("Enter radius:");
			double r = sc.nextInt();
			System.out.println("Enter height:");
			double h = sc.nextInt();
			System.out.println("Volume of a cylinder = "+v.volume(r,h));
			break;
		case 3:
			System.out.println("Enter Length:");
			double l = sc.nextInt();
			System.out.println("Enter Breadth:");
			double b = sc.nextInt();
			System.out.println("Enter Height:");
			double h1 = sc.nextInt();
			System.out.println("Volume of a Rectangle = "+v.volume(l,b,h1));
			break;
		}
	}

}
