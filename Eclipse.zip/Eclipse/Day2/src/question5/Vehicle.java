package question5;

class vehicle {
	private int noOfWheel;
	private int noOfPassenger;
	private int model;
	private String make;

	vehicle(int noOfWheels, int noOfPassengers, int model, String make) {
		this.noOfWheel = noOfWheels;
		this.noOfPassenger = noOfPassengers;
		this.model = model;
		this.make = make;
	}

	public String getwheel() {
		return "Number of wheels are " + noOfWheel;
	}

	public String getpassenger() {
		return "Number of Passengers are " + noOfPassenger;
	}

	public String getmodel() {
		return "Model of the vehicle" + model;
	}

	public String getmake() {
		return "Make of the vehicle " + make;
	}

	public void display() {
		System.out.println(getwheel());
		System.out.println(getpassenger());
		System.out.println(getmodel());
		System.out.println(getmake());
	}

}

