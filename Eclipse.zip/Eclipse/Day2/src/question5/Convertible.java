package question5;

class Convertible extends car {
	private boolean isHoodOpen;

	Convertible(int noOfWheels, int noOfPassengers, int model, int noOfDoors,
			boolean isHoodOpen, String make) {
		super(noOfWheels, noOfPassengers, model, noOfDoors, make);
		this.isHoodOpen = isHoodOpen;
	}

	public String getisHoodOpen() {
		String open = (isHoodOpen) ? "open" : "not open";
		return "The hood is " + open;
	}

	@Override
	public void display() {
		super.display();
		System.out.println(getisHoodOpen());
	}
}
