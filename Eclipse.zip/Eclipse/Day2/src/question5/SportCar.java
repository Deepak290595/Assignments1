package question5;

class SportsCar extends car{
    SportsCar(int noOfWheels, int noOfPassengers, int model, String make){
        super(noOfWheels, noOfPassengers, model, 2, make);
    }
    @Override
    public void display(){
        super.display();
    }
}

