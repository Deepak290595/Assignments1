package question5;
import java.util.Scanner;

class Application {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int k = 4;
		while (k-- > 0) {
			
			int test = s.nextInt();
			int noOfWheels, noOfPassengers, model, noOfDoors;
			boolean isHoodOpen;
			String make;
			switch (test) {
			case 1:
				noOfWheels = s.nextInt();
				noOfPassengers = s.nextInt();
				model = s.nextInt();
				make = s.next();
				vehicle ob = new vehicle(noOfWheels, noOfPassengers, model,make);
				ob.display();
				System.out.println();
				break;
			case 2:
				noOfWheels = s.nextInt();
				noOfPassengers = s.nextInt();
				model = s.nextInt();
				noOfDoors = s.nextInt();
				make = s.next();
				car ob1 = new car(noOfWheels, noOfPassengers, model, noOfDoors,make);
				ob1.display();
				System.out.println();
				break;
			case 3:
				noOfWheels = s.nextInt();
				noOfPassengers = s.nextInt();
				model = s.nextInt();
				noOfDoors = s.nextInt();
				isHoodOpen = s.nextBoolean();
				make = s.next();
				Convertible ob2 = new Convertible(noOfWheels, noOfPassengers,model, noOfDoors, isHoodOpen, make);
				ob2.display();
				System.out.println();
				break;
			case 4:
				
				noOfWheels = s.nextInt();
				noOfPassengers = s.nextInt();
				model = s.nextInt();
				make = s.next();
				SportsCar ob3 = new SportsCar(noOfWheels, noOfPassengers,model, make);
				ob3.display();
				System.out.println();
				break;
			default:
				System.out.println("Wrong Input");
			}s.close();
		}
	}
}
