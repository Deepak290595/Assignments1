package question4;

import java.util.Scanner;

public class StudentApplication {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int input;
		System.out
				.println("you want enter \n 1. only id \n 2. Id with name \n 3. all three values(id,name and grade)");
		input = sc.nextInt();
		System.out.println("1. Display with current year or 2. normal display");
		int inputDisplay = sc.nextInt();
		if (inputDisplay == 1) {
			switch (input) {
			case 1: {
				System.out.println("Enter Id");
				Student st = new Student(sc.next());
				System.out.println("Enter the year");
				st.display(sc.nextInt());
				break;
			}
			case 2: {
				System.out.println("Enter id and name");
				Student st = new Student(sc.next(), sc.next());
				System.out.println("Enter the year");
				st.display(sc.nextInt());
				break;
			}
			case 3: {
				System.out.println("Enter all three values");
				Student st = new Student(sc.next(), sc.next(), sc.nextDouble());
				System.out.println("Enter the year");
				st.display(sc.nextInt());
				break;
			}
			}
		} else {
			switch (input) {
			case 1: {
				System.out.println("Enter Id");
				Student st = new Student(sc.next());
				st.display();
				break;
			}
			case 2: {
				System.out.println("Enter id and name");
				Student st = new Student(sc.next(), sc.next());
				st.display();
				break;
			}
			case 3: {
				System.out.println("Enter all three values");
				Student st = new Student(sc.next(), sc.next(), sc.nextDouble());
				st.display();
				break;
			}
			}
		}

	}

}
