package question3;


import java.util.Scanner;

public class Banking {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("enter the account name");
		String name = scanner.next();

		System.out.println("Choice the type of account ");
		System.out.println("press 1 for saving account \n press 2 for cuurent account");
		int n = scanner.nextInt();

		System.out.println("enter initial balance");

		double balance = scanner.nextDouble();

		double bal = balance + 5.0 / 100 * balance;

		if (n == 1) {
			SavingAccount savingaccount = new SavingAccount(name, bal);
			// savingaccount.setAccountBalance();

			System.out
					.println("enter 1 for deposit money, 2 for withdraw money, 3 for display the account balance");
			int c = scanner.nextInt();
			switch (c) {
			case 1:
				System.out.println("enter money to deposit");
				double deposit = scanner.nextDouble();

				savingaccount.deposit(deposit);
				savingaccount.display();
				break;
			case 2:
				System.out.println("enter money to withdraw");
				double withdraw = scanner.nextDouble();
				savingaccount.withdraw(withdraw);
				savingaccount.display();
				break;
			case 3:
				savingaccount.display();
				break;

			}
		}
		if (n == 2) {
			CurrentAccount currentaccount = new CurrentAccount(name, balance);
			System.out.println("Enter 1 for deposit money");
			System.out.println("Enter 2 for withdraw money");
			System.out.println("Enter 3 for display the account balance");
			int input = scanner.nextInt();
			switch (input) {
			case 1:
				System.out.println("enter money to deposit");
				double deposit = scanner.nextDouble();

				currentaccount.deposit(deposit);
				currentaccount.display();
				break;
			case 2:
				System.out.println("enter money to withdraw");
				double withdraw = scanner.nextDouble();
				currentaccount.withdraw(withdraw);
				// savingaccount.display();
				break;
			case 3:
				currentaccount.display();
				break;
			}
		}
		scanner.close();
	}
}
