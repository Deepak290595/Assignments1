package question3;

public class SavingAccount extends Account {

	public SavingAccount(String accountHolderName, double accountBalance) {
		super(accountHolderName, accountBalance, "");
	}

	void getBalance() {

	}

	void deposit(double deposit) {
		super.setAccountBalance((super.getAccountBalance() + deposit));

	}

	void withdraw(double deposit) {
		if (super.getAccountBalance() > deposit) {
			super.setAccountBalance((super.getAccountBalance() - deposit));
		} else {
			System.out.println("balance can not be exceed than account balance");
		}

	}

}
