package question3;

import java.util.Random;

public class Account {

	private String accountHolderName;
	private double accountBalance;
	private String accountNumber;

	public Account() {
	}

	public Account(String accountHolderName, double accountBalance,
			String accountNumber) {
		Random rand = new Random();
		this.accountNumber = accountNumber + rand.nextInt(10)
				+ rand.nextInt(10) + rand.nextInt(10) + rand.nextInt(10)
				+ rand.nextInt(10);

		this.accountHolderName = accountHolderName;
		this.accountBalance = accountBalance;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	void display() {
		System.out.println(this.getAccountHolderName());
		System.out.println(this.getAccountNumber());
		System.out.println(this.getAccountBalance());

	}

}
