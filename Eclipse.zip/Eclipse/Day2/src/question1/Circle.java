package question1;

import java.text.DecimalFormat;
import java.util.Scanner;
//Java Program to get circle area
public class Circle {
      	private final double PI = 3.14159;//final value of PI
	   	private double radius;//private radius variable of double type
	    private String color;//
      //Default Constructor
	    public Circle() 
      {
	        radius = 0.0;
	    }
	    //parameterzed Constructor
      public Circle(double r) {
	        radius = r;
	    }
      public void setRadius(double r) //Setter method
      {
	        radius = r;
	    }
      public double getRadius() //getter method
      {
	        return radius;
	    }
      public double getArea() //getter Area method
      {
	        return PI * radius * radius;
	    }
      public static void main(String[] args) //main method
      {
    	  DecimalFormat df=new DecimalFormat("##.###");
          // Create a Scanner object for input.
          Scanner sc = new Scanner(System.in);

          //input circle radius
          System.out.print("Enter the radius of a circle: ");
          double radius = sc.nextDouble();

          // close sc
          sc.close();

          // Create a Circle object passing in user input
          Circle circle1 = new Circle();
          Circle circle2 = new Circle(radius);
          // Display circle information
          System.out.println("Area is " + df.format(circle2.getArea()));

      }
}



