package question2;
import java.util.Scanner;
public class BookStore {
	public Book books[];
	int num;
	String Title,Author,ISBN;
	int Copies;
	Scanner sc = new Scanner(System.in);
	public void initialize(){
		System.out.println("Enter no. of books: ");
		num = sc.nextInt();
		books = new Book[num];
		for(int i=0;i<num;i++){
			System.out.println("Enter Book Title: ");
			Title=sc.next();
			System.out.println("Enter author: ");
			Author=sc.next();
			System.out.println("Enter ISBN: ");
			ISBN=sc.next();
			System.out.println("Enter no. of copies: ");
			Copies=sc.nextInt();
			books[i]=new Book(Title,Author,ISBN,Copies);
		}
	}
	public BookStore(Book[] books) {
		this.books = books;
	}
	public BookStore() {
	}
	void sell(String bookTitle,int noOfCopies){
		for (int i = 0; i < num; i++) {
		if(books[i].getBookTitle().equalsIgnoreCase(bookTitle)){
			books[i].setNumOfCopies(books[i].getNumOfCopies()-noOfCopies);
		}
		else{
			System.out.println("Book not found...");
		}
		}
	}
	void order(String iSBN,int noOfCopies){
		for(int i=0;i<num;i++){
			if(books[i].getiSBN().equalsIgnoreCase(iSBN)){
				books[i].setNumOfCopies(books[i].getNumOfCopies()+noOfCopies);
			}
			else{
				System.out.println("New Book"+"\n"+"Enter details");
				System.out.println("Enter Book Title: ");
				books[i].setBookTitle(sc.next());
				System.out.println("Enter author: ");
				books[i].setAuthor(sc.next());
				System.out.println("Enter ISBN: ");
				books[i].setiSBN(sc.next());
				System.out.println("Enter no. of copies: ");
				books[i].setNumOfCopies(sc.nextInt());
				num++;
			}
		}
	}
	void display(){
		System.out.println("Books Details:");
		for(int i =0;i<num;i++){
			System.out.println(books[i].getBookTitle()+"-"+books[i].getAuthor()+"-"+books[i].getiSBN()+"-"+books[i].getNumOfCopies());
		}
	}
	
}
