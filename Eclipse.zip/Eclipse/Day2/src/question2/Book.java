package question2;

public class Book {
	private String bookTitle;
	private String author;
	private String iSBN;
	private int numOfCopies;
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getiSBN() {
		return iSBN;
	}
	public void setiSBN(String iSBN) {
		iSBN = iSBN;
	}
	public int getNumOfCopies() {
		return numOfCopies;
	}
	public void setNumOfCopies(int numOfCopies) {
		this.numOfCopies = numOfCopies;
	}
	Book(){
		 this("null","null","null",0);
	}
	public Book(String bookTitle, String author, String iSBN, int numOfCopies) {
		this.bookTitle = bookTitle;
		this.author = author;
		this.iSBN = iSBN;
		this.numOfCopies = numOfCopies;
	}
	void display(){
		System.out.println(this.bookTitle+"-"+this.author+"-"+this.iSBN+"-"+this.numOfCopies);
	}
	

}
