package question4;
class Hosteler extends Student{
	String hostelName="abc";
	int roomNo=105;
	void display(){
		this.hostelName="bcd";
		this.phoneNo=7827718534L;
		System.out.println(this.stName +" "+this.stID+ " "+this.sex+" "+hostelName+" "+phoneNo);
	}
	
	}
public class Student {
	int stID=123;
	String stName="Deepak";
	String sex= "Male";
	long phoneNo=8964999700L;
	public static void main(String[] args) {
		Hosteler h=new Hosteler();
		h.display();
	}
	
}
