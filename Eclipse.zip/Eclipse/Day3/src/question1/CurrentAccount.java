package question1;

public class CurrentAccount extends Account {
	Account account = new Account();
	double serviceCharge;

	public double penalty() {
		if (account.getAccountBalance() < 1000) {
			serviceCharge = 0.01 * account.getAccountBalance();
			setAccountBalance(getAccountBalance() - serviceCharge);
			return getAccountBalance();
		} else {
			System.out.println("andha paisa hai !!");
			return 0;
		}
	}

	public double chequeAmount(double chequeAmount) {
		if (getAccountBalance() > 0)
			setAccountBalance(getAccountBalance() - chequeAmount);
		return getAccountBalance();

	}

}
