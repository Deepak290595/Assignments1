package question1;

public class Account {

	private String customerName, accountType;
	private double accountNumber, accountBalance=50000;

	Account() {
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getAccountType() {
		return accountType;
	}

	public double getAccountNumber() {
		return accountNumber;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public void setAccountNumber(double accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public double withdraw(double amount) {
		accountBalance -= amount;
		return accountBalance;
	}

	/*
	 * public double getBalance() { return accountBalance; }
	 */

	public double deposit(double depositAmount) {
		setAccountBalance(getAccountBalance() + depositAmount);
		return getAccountBalance();
	}

	public double display() {
		return getAccountBalance();
	}

}
