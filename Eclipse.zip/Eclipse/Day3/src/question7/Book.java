package question7;

class Periodical extends Book{
	String period = "Weekly";
	void modify(){
		this.period="Monthly";
		this.price=50;
	}
	void display(){
		System.out.println("Details: "+this.period+ " "+this.price); 
	}
}
public class Book {
	int bookID=101;
	String title="Gelvin";
	String author ="abc";
	double price=60;
	public static void main(String[] args) {
		Periodical e = new Periodical();
		e.display();
		e.modify();
		e.display();
	}

}
